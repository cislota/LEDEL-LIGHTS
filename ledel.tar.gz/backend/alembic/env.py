from logging.config import fileConfig

from sqlalchemy import engine_from_config
from sqlalchemy import pool

from alembic import context

# Конфигурация Alembic
config = context.config

# Интерпретировать файл конфигурации для логирования Python.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Добавьте объект MetaData вашей модели здесь для поддержки 'autogenerate'
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from database import Base
from models import Product, Order, OrderItem, Category, QuizResult, ContactFormSubmission, SyncLog

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Запустить миграции в 'оффлайн' режиме."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Запустить миграции в 'онлайн' режиме."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
