// src/components/sections/Footer.tsx
'use client';

import Image from 'next/image';
import { useRouter, usePathname } from 'next/navigation';

export default function Footer() {
    const router = useRouter();
    const pathname = usePathname();
    
    const handleLogoClick = () => {
      if (pathname === '/') {
        window.scroll({ top: 0, behavior: 'smooth'}); //если страница на главной - скролл вверх
      } else {
        router.push('/'); // переход на главную, скролл
        setTimeout (() => {
          window.scrollTo ({top: 0, behavior: 'smooth'}); // дилей прогрузки для домена
        }, 100)
      }
    };

  return (
    <footer
      className="bg-gray-100 py-8"
      style={{ backgroundColor: '#eeeeee' }}
    >
      <div className="container mx-auto px-4">
        {/* Верхняя часть: 4 колонки */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* Колонка 1: логотип — скролл наверх */}
          <div className="md:col-span-1 md:row-span-2 flex items-center">
            <button
              type = "button"
              aria-label = "На главную"
              onClick = {handleLogoClick}
              className = "cursor-pointer"
            >
              <Image
                src="/media/logo.svg"
                alt="LEDEL"
                width={200}
                height={40}
                className="object-contain"
                priority
              />
            </button>
          </div>

          {/* Колонка 2: телефон email — кликабельные */}
          <div className="md:col-span-1">
            <a
              href="tel:+78003510975"
              style={{
                fontSize: '16px',
                fontFamily: '"TildaSans", Arial, sans-serif',
                color: '#666666',
                margin: '0 0 4px 0',
                display: 'block',
                textDecoration: 'none',
              }}
              className="hover:underline"
            >
              8 (800) 351-09-75
            </a>
            <a
              href="mailto:info@ledl-lights.ru"
              style={{
                fontSize: '16px',
                fontFamily: '"TildaSans", Arial, sans-serif',
                color: '#666666',
                margin: 0,
                display: 'block',
                textDecoration: 'none',
              }}
              className="hover:underline"
            >
              info@ledl-lights.ru
            </a>
          </div>

          {/* Колонка 3: адрес */}
          <div className="md:col-span-1">
            <p
              style={{
                fontSize: '16px',
                fontFamily: '"TildaSans", Arial, sans-serif',
                color: '#666666',
                margin: '0 0 4px 0',
              }}
            >
              г. Санкт-Петербург
            </p>
            <p
              style={{
                fontSize: '16px',
                fontFamily: '"TildaSans", Arial, sans-serif',
                color: '#666666',
                margin: 0,
              }}
            >
              ул. Дибуновская, д.45
            </p>
          </div>

          {/* Колонка 4: рабочее время */}
          <div className="md:col-span-1">
            <p
              style={{
                fontSize: '16px',
                fontFamily: '"TildaSans", Arial, sans-serif',
                color: '#666666',
                margin: '0 0 4px 0',
              }}
            >
              Рабочее время:
            </p>
            <p
              style={{
                fontSize: '16px',
                fontFamily: '"TildaSans", Arial, sans-serif',
                color: '#666666',
                margin: 0,
              }}
            >
              9:00 – 18:00 (пн–пт)
            </p>
          </div>
        </div>

        {/* Разделительная линия */}
        <div
          className="w-full border-t border-gray-300 mb-6"
          style={{ borderColor: '#cccccc' }}
        />

        {/* Нижняя строка */}
        <div className="flex flex-col sm:flex-row justify-between items-center text-sm">
          <a
            href="https://re-spond.com/"
            target="_blanl"
            rel="noopener noreffer"
            style={{
              fontSize: '14px',
              fontFamily: '"TildaSans", Arial, sans-serif',
              color: '#666666',
            }}
            className="hover:underline"
          >
            Сделано в RE:SPOND
          </a>
          <div
            style={{
              fontSize: '14px',
              fontFamily: '"TildaSans", Arial, sans-serif',
              color: '#666666',
            }}
          >
            <a href="/privacy" className="hover:underline">
              Политика конфиденциальности
            </a>
          </div>
          <div
            style={{
              fontSize: '14px',
              fontFamily: '"TildaSans", Arial, sans-serif',
              color: '#666666',
            }}
          >
            © 2024 СветКонсалт
          </div>
        </div>
      </div>

      {/* Кнопка "Вверх" */}
      <button
        type="button"
        aria-label="Наверх"
        className="fixed bottom-6 right-6 w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center transition-all duration-300"
        style={{ border: '1px solid #cccccc' }}
        onMouseEnter={(e) => {
          e.currentTarget.style.backgroundColor = '#d5302c';
          const img = e.currentTarget.querySelector('img');
          if (img) img.style.filter = 'brightness(0) invert(1)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.backgroundColor = '#ffffff';
          const img = e.currentTarget.querySelector('img');
          if (img) img.style.filter = 'none';
        }}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
      >
        <Image
          src="/media/Vector(1)red.svg"
          alt="Вверх"
          width={16}
          height={16}
          className="object-contain"
          style={{ transform: 'rotate(270deg)' }}
          aria-hidden="true"
        />
      </button>
    </footer>
  );
}